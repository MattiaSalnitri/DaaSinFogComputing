#!/bin/bash

#start setup
echo "start batch"

#add libraries of functions
PATH_LIBRARY="/home/salnitri/scripts/library_V2.sh"
. $PATH_LIBRARY

echo "start training"
date

#define application for training in VMs
TRAINING_VM1=( 1 2 3 4 5 6 7 8 9 10 )
TRAINING_VM2=( 11 12 13 14 15 16 17 18 19 20 )

echo "start batch"
# date
# echo "Training applications VM1: "${TRAINING_VM1[@]}
# echo "Training applications VM2: "${TRAINING_VM2[@]}


# ./setupScriptVM1.sh "${#TRAINING_VM1[@]}" "${TRAINING_VM1[@]}" "${#TRAINING_VM2[@]}" "${TRAINING_VM2[@]}" >> trainingLogs 2>&1

date
echo "training finished"

echo "start test"

BATCH=4

#start tests
for EMPTYNODES in 0 3 5 7 10
do
        echo "start batch for empty nodes: "$EMPTYNODES
        date

        RESULT=""
        #for each number of applications involved
        for APPLICATION in 3 5 10 15 20
        do

                echo "Setting up test for application: "$APPLICATION

                #create arrays of applications
                createApplicationsVectorTest $APPLICATION
                echo "Applications VM1: "${APPLICATIONS_VM1[@]}
                echo "Applications VM2: "${APPLICATIONS_VM2[@]}

                #call test script setup
                ./testScriptSetupVM1_vector.sh $APPLICATION $EMPTYNODES "${#APPLICATIONS_VM1[@]}" "${APPLICATIONS_VM1[@]}"  "${#APPLICATIONS_VM2[@]}" "${APPLICATIONS_VM2[@]}"                 

                #for all applications test initial positions
                for POSITION in ${APPLICATIONS_VM1[@]} ${APPLICATIONS_VM2[@]}
                do        
                        TESTRESULT=$(./testScriptStartVM1.sh $POSITION $APPLICATION $EMPTYNODES "${#APPLICATIONS_VM1[@]}" "${APPLICATIONS_VM1[@]}"  "${#APPLICATIONS_VM2[@]}" "${APPLICATIONS_VM2[@]}" )
                        RESULT=$RESULT$TESTRESULT";"
                done

                echo $RESULT>>"batch_"$BATCH"_"$EMPTYNODES
                RESULT=""
        done 
        
        date 
        echo "end batch"
done

echo "end test"