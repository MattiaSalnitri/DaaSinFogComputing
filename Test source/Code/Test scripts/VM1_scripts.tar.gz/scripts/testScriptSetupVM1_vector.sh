#!/bin/bash
#script test in VM1

#paramters
#1- application number
#2- number of empty nodes
#3- size of array that contains the set of application to be built in VM1
#4- set of application to be built in VM1
#5- size of array that contains the set of application to be built in VM2
#6- set of application to be built in VM2

#add variables
. configuration.sh

#add libraries of functions
. $PATH_LIBRARY

#start scripts 
echo "Start testScriptSetupVM1" >> $PATH_LOG_VM1

#change current dir
cd /home/mangiaracina/prova/VM1

#inputs
#set the number of nodes
APPLICATIONS_NUMBER=$1
EMPTY_NODES_NUMBER=$2

#retrive array of application to build
#shift the alrady saved parameters, to correctly retrive array
shift 2


############extract arrays
######extract first array
declare -i num_args; #integers
declare -a APPLICATIONS_VM1; #declare the name of the array

APPLICATIONS_VM1=( )
num_args=$1; shift
#decrease num args and ceck idf the decresed value is higher than 0
while (( num_args-- > 0 )) ; do 
    APPLICATIONS_VM1+=( "$1" ); shift
done

######extract second array
declare -a APPLICATIONS_VM2; #declare the name of the array

APPLICATIONS_VM2=( )
num_args=$1; shift
#decrease num args and ceck idf the decresed value is higher than 0
while (( num_args-- > 0 )) ; do 
    APPLICATIONS_VM2+=( "$1" ); shift
done
###########################

#set a unique array fo all applications
APPLICATIONS=(${APPLICATIONS_VM1[@]} ${APPLICATIONS_VM2[@]})


#check parame size
if [ ! APPLICATIONS_NUMBER=${#APPLICATIONS[@]} ]; then
    echo "ERROR: Application number is not consistent with set of application to instantiate"
fi


echo "Parameters" >> $PATH_LOG_VM1
echo "Applications number VM1: "$APPLICATIONS_NUMBER >> $PATH_LOG_VM1
echo "Empty nodes number VM1: "$EMPTY_NODES_NUMBER >> $PATH_LOG_VM1
echo "Applications: "${APPLICATIONS[@]} >> $PATH_LOG_VM1
echo "Applications VM1: "${APPLICATIONS_VM1[@]} >> $PATH_LOG_VM1
echo "Applications VM2: "${APPLICATIONS_VM2[@]} >> $PATH_LOG_VM1


#check if minio and SQL container are up and running
#if it is not the case the sctipts stops
checkContainersVM1 >> $PATH_LOG_EXTRA_VM1 2>&1
echo "Check container passed"  >> $PATH_LOG_VM1

#clear docker
docker system prune -f -a --volumes >> $PATH_LOG_EXTRA_VM1 2>&1
echo "docker pruned" >> $PATH_LOG_VM1

#update db.py for each spark folder, to set the number of applications
find . -regextype posix-extended -regex ".*db.py" -type f -exec sed -i "s/N =.*/N = ${APPLICATIONS_NUMBER}/g" {} \; >> $PATH_LOG_EXTRA_VM1 2>&1
echo "db.py updated"  >> $PATH_LOG_VM1

#modify all actions.py files with the list of nodes and uncommenting the ones required
setNodesVector $APPLICATIONS_NUMBER $EMPTY_NODES_NUMBER $MAX_AVAILABLE_NODE "${APPLICATIONS[@]}" >> $PATH_LOG_EXTRA_VM1 2>&1

echo "action.py cleared"  >> $PATH_LOG_VM1

#launch setup on VM2 (injection version)
sshpass -f <(printf '%s\n' $PASSWORD) ssh salnitri@10.75.4.66 "echo $PASSWORD | sudo -S nohup ${PATH_SETUP_TEST_SCRIPT_VM2_VECTOR} ${APPLICATIONS_NUMBER} ${EMPTY_NODES_NUMBER} ${MAX_AVAILABLE_NODE} ${PATH_LOG_EXTRA_VM2} ${PATH_DOCKER_COMPOSE_VM2} ${#APPLICATIONS_VM1[@]} ${APPLICATIONS_VM1[@]} ${#APPLICATIONS_VM2[@]} ${APPLICATIONS_VM2[@]} >> $PATH_LOG_VM2 2>&1" &


#create docker compose based on the number of application
#creates half of the applications, the remaining application will be started in vm2, that is more free than vm1. integer division
createDockerComposeVector $PATH_DOCKER_COMPOSE_VM1 "${APPLICATIONS_VM1[@]}" >> $PATH_LOG_EXTRA_VM1 2>&1

#build spark containers
docker-compose build >> $PATH_LOG_EXTRA_VM1 2>&1
#here I implicilty wait to end the command, DON'T put "&"

echo "Images for docker container compiled"  >> $PATH_LOG_VM1
