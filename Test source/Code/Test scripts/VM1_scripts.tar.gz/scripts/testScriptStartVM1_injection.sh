#!/bin/bash
#script test in VM1
#Injection: do not clean db before the starts, it accepts the configuration in the db. it restore configuration and db


#paramters
#1- current position of data set
#2- number of applications
#3- number of empty nodes
#4- size of the array of application to be deployed in VM1
#5- array of application to be deployed in VM1
#6- size of the array of application to be deployed in VM2
#7- array of application to be deployed in VM2

#add variables
. configuration.sh

#add libraries of functions
. $PATH_LIBRARY

#inputs
#initial position
CURRENT_POSITION=$1
#set the number of nodes
APPLICATIONS_NUMBER=$2
EMPTY_NODES_NUMBER=$3

#retrive array of application to build
#shift the already saved parameters, to correctly retrive array
shift 3

############extract arrays
######extract first array
declare -i num_args; #integers
declare -a APPLICATIONS_VM1; #declare the name of the array

APPLICATIONS_VM1=( )
num_args=$1; shift
while (( num_args-- > 0 )) ; do #decrease num args and check if the decresed value is higher than 0
    APPLICATIONS_VM1+=( "$1" ); shift
done

######extract second array
declare -a APPLICATIONS_VM2; #declare the name of the array

APPLICATIONS_VM2=( )
num_args=$1; shift
while (( num_args-- > 0 )) ; do #decrease num args and check if the decresed value is higher than 0
    APPLICATIONS_VM2+=( "$1" ); shift
done
###########################

#set a unique array fo all applications
APPLICATIONS=(${APPLICATIONS_VM1[@]} ${APPLICATIONS_VM2[@]})

#start scripts
echo "script start" >> $PATH_LOG_VM1

echo "Parameters" >> $PATH_LOG_VM1
echo "Current position: "$CURRENT_POSITION >> $PATH_LOG_VM1
echo "Applications number: "$APPLICATIONS_NUMBER >> $PATH_LOG_VM1
echo "Empty nodes number: "$EMPTY_NODES_NUMBER >> $PATH_LOG_VM1
echo "Applications: "${APPLICATIONS[@]} >> $PATH_LOG_VM1

#check that minio and SQL container are up and running
#if it is not the casethe sctipts stops
checkContainersVM1 >> $PATH_LOG_EXTRA_VM1 2>&1
echo "Check container passed"  >> $PATH_LOG_VM1

#change current dir
cd /home/mangiaracina/prova/VM1

###not for injection! keep the data set where they are
#clear db with initial position of dataset
#mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "TRUNCATE TABLE file_table; INSERT INTO file_table Values(1,$CURRENT_POSITION)" >> $PATH_LOG_EXTRA_VM1 2>&1
#echo "reset datasets positions, initial position dataset updated"  >> $PATH_LOG_VM1

echo "test with dataset in position $CURRENT_POSITION"  >> $PATH_LOG_VM1

#launch test on VM2
#it needs to be launched after db setup
PATH_START_TEST_SCRIPT_VM2_INJECTION="/home/salnitri/scripts/testScriptVM2_start_preInjection.sh"
sshpass -f <(printf '%s\n' $PASSWORD) ssh salnitri@10.75.4.66 "echo $PASSWORD | sudo -S nohup ${PATH_START_TEST_SCRIPT_VM2_INJECTION} ${APPLICATIONS_NUMBER} ${PATH_LOG_EXTRA_VM2} ${#APPLICATIONS_VM2[@]} ${APPLICATIONS_VM2[@]} >> $PATH_LOG_VM2 2>&1" &

#start spark applications
docker-compose up -d >> $PATH_LOG_EXTRA_VM1 2>&1

#starts half of the applications (spark history server e toxiproxy), the remaining application will be strted in vm2, that is more free than vm1. integer division
#initialiseSparkNodesVM1 $(( APPLICATIONS_NUMBER/2 )) >> $PATH_LOG_EXTRA_VM1 2>&1
initialiseSparkNodes_vector ${APPLICATIONS_VM1[@]} >> $PATH_LOG_EXTRA_VM1 2>&1
echo "spark history server and toxiproxy launched"  >> $PATH_LOG_VM1

echo "giving time to boot servers"  >> $PATH_LOG_VM1
sleep 5m >> $PATH_LOG_EXTRA_VM1 2>&1

#starts half of the applications, the remaining application will be strted in vm2, that is more free than vm1. integer division
#startTestVM1 $(( APPLICATIONS_NUMBER/2 )) >> $PATH_LOG_EXTRA_VM1 2>&1
startTest_vector ${APPLICATIONS_VM1[@]} >> $PATH_LOG_EXTRA_VM1 2>&1
echo "test launched"  >> $PATH_LOG_VM1

#controllo l'ultimo evento, se sum_feedback e' a zero allora
#aspetto 10 minuti, se quello continua ad essere l'ultimo evento, allora chiudo
EVENTID_OLD=-1
while true; do
	#controllo tabella event
	EVENTID=$(mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "SELECT id from events WHERE sum_feedback<>0 ORDER BY id DESC LIMIT 1" 2>>$PATH_LOG_EXTRA_VM1)

	#controllo risultato
	if [[ $EVENTID -eq $EVENTID_OLD ]]
	then
		break
	else
		sleep 10m >> $PATH_LOG_EXTRA_VM1 2>&1
	fi
	#update event id old with current id
	EVENTID_OLD=$EVENTID
done

echo "test finished"  >> $PATH_LOG_VM1 

#saves the number of iterations
ACTIONSNUMBER=$(mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "SELECT count(*) FROM events JOIN ( SELECT id from events WHERE sum_feedback<>0 ORDER BY id DESC LIMIT 1 ) AS lastMove ON events.id<=lastMove.id" 2>>$PATH_LOG_EXTRA_VM1) 

echo "adaptation anctions: "$ACTIONSNUMBER >> $PATH_LOG_VM1

#take down spark containers
sudo docker-compose down >> $PATH_LOG_EXTRA_VM1 2>&1

echo "spark containers killed" >> $PATH_LOG_VM1
echo "spark containers killed" >> $PATH_LOG_EXTRA_VM1 2>&1

#cleanup machine 2
sshpass -f <(printf '%s\n' $PASSWORD) ssh salnitri@10.75.4.66 "echo $PASSWORD | sudo -S nohup ${PATH_STOP_TEST_SCRIPT_VM2_INJECTION} ${PATH_LOG_EXTRA_VM2} >> $PATH_LOG_VM2 2>&1" >> $PATH_LOG_EXTRA_VM1 2>&1 &


#################
echo "Dumping DB" >> $PATH_LOG_EXTRA_VM1 2>&1

#dump db for later inspection
FILE_DUMP_DB=$TMP_TRAINING_DIR"/dump_"${#APPLICATIONS[@]}
if [ -f "$FILE_DUMP_DB" ]; then
    echo "$FILE_DUMP_DB exists, dump db original not created" >> $PATH_LOG_VM1 
else
	mysqldump -h 10.75.4.65 --port 3308 -u root -phelloworld db >> $FILE_DUMP_DB
fi
echo "Dumped DB" >> $PATH_LOG_EXTRA_VM1 2>&1

#drop database
mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "DROP database db" >> $PATH_LOG_EXTRA_VM1 2>&1
echo "Dropped DB" >> $PATH_LOG_EXTRA_VM1 2>&1
#restore dump db for next iteration
#creates the database
mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -e "create database db" >> $PATH_LOG_EXTRA_VM1 2>&1
echo "Created DB" >> $PATH_LOG_EXTRA_VM1 2>&1

#dump data of db after converngence pre injections
mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db < $TMP_TRAINING_DIR"/dumpInjection" >> $PATH_LOG_EXTRA_VM1 2>&1
echo "Loaded injection DB" >> $PATH_LOG_EXTRA_VM1 2>&1


## file_table and global counter are not cleaned since they will be use later for other iterations.
#clean events table
mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "TRUNCATE TABLE events" >> $PATH_LOG_EXTRA_VM1 2>&1

echo "DB cleaned" >> $PATH_LOG_VM1
#################

echo $ACTIONSNUMBER