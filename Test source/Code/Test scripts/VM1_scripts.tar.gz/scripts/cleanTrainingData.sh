#!/bin/bash

#script cleaning data in VM1

#paramters
#1- size of array that contains the set of application to be built in VM1
#2- set of application to be built in VM1
#3- size of array that contains the set of application to be built in VM2
#4- set of application to be built in VM2

#add variables
. configuration.sh

#add libraries of functions
. $PATH_LIBRARY

############extract arrays
######extract first array
declare -i num_args; #integers
declare -a APPLICATIONS_VM1; #declare the name of the array

APPLICATIONS_VM1=( )
num_args=$1; shift
#decrease num args and ceck idf the decresed value is higher than 0
while (( num_args-- > 0 )) ; do 
    APPLICATIONS_VM1+=( "$1" ); shift
done

######extract second array
declare -a APPLICATIONS_VM2; #declare the name of the array

APPLICATIONS_VM2=( )
num_args=$1; shift
#decrease num args and ceck idf the decresed value is higher than 0
while (( num_args-- > 0 )) ; do 
    APPLICATIONS_VM2+=( "$1" ); shift
done
###########################

#set a unique array fo all applications
APPLICATIONS=(${APPLICATIONS_VM1[@]} ${APPLICATIONS_VM2[@]})


#check parame size
if [ ! APPLICATIONS_NUMBER=${#APPLICATIONS[@]} ]; then
    echo "ERROR: Application number is not consistent with set of application to instantiate"
fi


# echo "Parameters" >> $PATH_LOG_VM1
# echo "Applications VM1: "${APPLICATIONS_VM1[@]} >> $PATH_LOG_VM1
# echo "Applications VM2: "${APPLICATIONS_VM2[@]} >> $PATH_LOG_VM1


#change current dir
cd /home/mangiaracina/prova/VM1

#restore vector backup
#remove training for the element specific in array
for i in ${APPLICATIONS_VM1[@]}
do  
    #remove all vectors
    find spark$i -regextype posix-extended -regex ".*(IC|IM|CR).*" -type f -exec rm {} \;
done


# copy all backup in original folder
#remove training for the element specified in array
for i in ${APPLICATIONS_VM1[@]}
do  
    #copy all training files
    cp  $TMP_TRAINING_DIR/spark$i/* /home/mangiaracina/prova/VM1/spark$i/.
done

#remove tmp folder

#clean DB

#drop database
mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "DROP database db" >> $PATH_LOG_EXTRA_VM1 2>&1
#restore dump db for next iteration
#creates the database
mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -e "create database db" >> $PATH_LOG_EXTRA_VM1 2>&1
#dump data of db after converngence pre injections
mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db < $TMP_TRAINING_DIR"/dumpOriginal" >> $PATH_LOG_EXTRA_VM1 2>&1

##clean
#clean file_table  table
#mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "TRUNCATE TABLE file_table" >> $PATH_LOG_EXTRA_VM1 2>&1

#clean events table -> only table that is truncated, to keep tracks of new events
mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "TRUNCATE TABLE events" >> $PATH_LOG_EXTRA_VM1 2>&1

#update global counter 
#mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "update global_counter set value=0" >> $PATH_LOG_EXTRA_VM1 2>&1

#clean VM2

#path to VM2 script to call
PATH_CLEAN_TRAINING_DATA_VM2="/home/salnitri/scripts/cleanTrainingDataVM2.sh "
#cleanup machine 2
sshpass -f <(printf '%s\n' $PASSWORD) ssh salnitri@10.75.4.66 "echo $PASSWORD | sudo -S nohup ${PATH_CLEAN_TRAINING_DATA_VM2} ${#APPLICATIONS_VM2[@]} ${APPLICATIONS_VM2[@]} >> $PATH_LOG_VM2 2>&1" >> $PATH_LOG_EXTRA_VM1 2>&1 &

echo "DB resetted as before injection" >> $PATH_LOG_VM1