#!/bin/bash
#script test in VM1
#copy original configuratioin files it tmp folder does not exists
#preInjection: do not clean db at the end, it prepares for the injection of new app

#paramters
#1- current position of data set
#2- number of applications
#3- number of empty nodes
#4- size of the array of application to be deployed in VM1
#5- array of application to be deployed in VM1
#6- size of the array of application to be deployed in VM2
#7- array of application to be deployed in VM2

#add variables
. configuration.sh

#add libraries of functions
. $PATH_LIBRARY

#start scripts
echo "script start" >> $PATH_LOG_VM1

#inputs
#initial position
CURRENT_POSITION=$1
#set the number of nodes
APPLICATIONS_NUMBER=$2
EMPTY_NODES_NUMBER=$3


#retrive array of application to build
#shift the already saved parameters, to correctly retrive array
shift 3

############extract arrays
######extract first array
declare -i num_args; #integers
declare -a APPLICATIONS_VM1; #declare the name of the array

APPLICATIONS_VM1=( )
num_args=$1; shift
while (( num_args-- > 0 )) ; do #decrease num args and ceck idf the decresed value is higher than 0
    APPLICATIONS_VM1+=( "$1" ); shift
done

######extract second array
declare -a APPLICATIONS_VM2; #declare the name of the array

APPLICATIONS_VM2=( )
num_args=$1; shift
while (( num_args-- > 0 )) ; do #decrease num args and ceck idf the decresed value is higher than 0
    APPLICATIONS_VM2+=( "$1" ); shift
done
###########################

#set a unique array fo all applications
APPLICATIONS=(${APPLICATIONS_VM1[@]} ${APPLICATIONS_VM2[@]})

echo "Parameters" >> $PATH_LOG_VM1
echo "Current position: "$CURRENT_POSITION >> $PATH_LOG_VM1
echo "Applications number: "$APPLICATIONS_NUMBER >> $PATH_LOG_VM1
echo "Empty nodes number: "$EMPTY_NODES_NUMBER >> $PATH_LOG_VM1
echo "Applications: "${APPLICATIONS[@]} >> $PATH_LOG_VM1


#check that minio and SQL container are up and running
#if it is not the casethe sctipts stops
checkContainersVM1 >> $PATH_LOG_EXTRA_VM1 2>&1
echo "Check container passed"  >> $PATH_LOG_VM1

#change current dir
cd /home/mangiaracina/prova/VM1

##########################
#different part: control if tmp exists
if [ ! -d "$TMP_TRAINING_DIR" ]; then
  ### if $DIR does not exist, create and copy  original vectors ###
  mkdir $TMP_TRAINING_DIR
  for ((i=1;i<=10;i++));#copy all training, for backup to be restored later
    do  
		#create the sub folder
		mkdir $TMP_TRAINING_DIR/spark$i
		#copy all training files
        cp /home/mangiaracina/prova/VM1/spark$i/I*  $TMP_TRAINING_DIR/spark$i/.
    done

	#dump database, done only once 
	# mysqldump -h 10.75.4.65 --port 3308 -u root -phelloworld db >> $TMP_TRAINING_DIR"/dumpOriginal"
fi

#dump database after convergence, done only once
FILE_DUMPORIGINAL=$TMP_TRAINING_DIR"/dumpOriginal"
if [ -f "$FILE_DUMPORIGINAL" ]; then
    echo "$FILE_DUMPORIGINAL exists, dump db original not created" >> $PATH_LOG_VM1 
else
	mysqldump -h 10.75.4.65 --port 3308 -u root -phelloworld db >> $FILE_DUMPORIGINAL
fi


##########################

#clear db with initial position of dataset
mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "TRUNCATE TABLE file_table; INSERT INTO file_table Values(1,$CURRENT_POSITION)" >> $PATH_LOG_EXTRA_VM1 2>&1
echo "reset datasets positions, initial position dataset updated"  >> $PATH_LOG_VM1

echo "test with dataset in position $CURRENT_POSITION"  >> $PATH_LOG_VM1


###########################
#modifyed since it calls a different script
#launch test on VM2
#it needs to be launched after db setup

sshpass -f <(printf '%s\n' $PASSWORD) ssh salnitri@10.75.4.66 "echo $PASSWORD | sudo -S nohup ${PATH_START_TEST_SCRIPT_VM2_PREINJECTION} ${APPLICATIONS_NUMBER} ${PATH_LOG_EXTRA_VM2} ${#APPLICATIONS_VM2[@]} ${APPLICATIONS_VM2[@]} >> $PATH_LOG_VM2 2>&1" &
############################

#start spark applications
docker-compose up -d >> $PATH_LOG_EXTRA_VM1 2>&1

#starts half of the applications (spark history server e toxiproxy), the remaining application will be strted in vm2, that is more free than vm1. integer division
#initialiseSparkNodesVM1 $(( APPLICATIONS_NUMBER/2 )) >> $PATH_LOG_EXTRA_VM1 2>&1
initialiseSparkNodes_vector ${APPLICATIONS_VM1[@]} >> $PATH_LOG_EXTRA_VM1 2>&1
echo "spark history server and toxiproxy launched"  >> $PATH_LOG_VM1

echo "giving time to boot servers"  >> $PATH_LOG_VM1
sleep 5m >> $PATH_LOG_EXTRA_VM1 2>&1

#starts half of the applications, the remaining application will be strted in vm2, that is more free than vm1. integer division
#startTestVM1 $(( APPLICATIONS_NUMBER/2 )) >> $PATH_LOG_EXTRA_VM1 2>&1
startTest_vector ${APPLICATIONS_VM1[@]} >> $PATH_LOG_EXTRA_VM1 2>&1

echo "test launched"  >> $PATH_LOG_VM1

#controllo l'ultimo evento, se sum_feedback e' a zero allora
#aspetto 10 minuti, se quello continua ad essere l'ultimo evento, allora chiudo
EVENTID_OLD=-1
while true; do
	#controllo tabella event
	EVENTID=$(mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "SELECT id from events WHERE sum_feedback<>0 ORDER BY id DESC LIMIT 1" 2>>$PATH_LOG_EXTRA_VM1)

	#controllo risultato
	if [[ $EVENTID -eq $EVENTID_OLD ]]
	then
		break
	else
		sleep 10m >> $PATH_LOG_EXTRA_VM1 2>&1
	fi
	#update event id old with current id
	EVENTID_OLD=$EVENTID
done

echo "test finished"  >> $PATH_LOG_VM1 

#saves the number of iterations
ACTIONSNUMBER=$(mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "SELECT count(*) FROM events JOIN ( SELECT id from events WHERE sum_feedback<>0 ORDER BY id DESC LIMIT 1 ) AS lastMove ON events.id<=lastMove.id" 2>>$PATH_LOG_EXTRA_VM1) 

##########################
#remove training and copy the updated one from spark machines, this will allow to have update training vectors with the convergence obtained with 10 elements
#remove training for the element specified in array
for i in ${APPLICATIONS_VM1[@]}
do  
	#remove all vectors
	find spark$i -regextype posix-extended -regex ".*(IC|IM|CR).*" -type f -exec rm {} \;
done

#backup applications specified in the array
backupTrainingVectors_vector "/home/mangiaracina/prova/VM1/" ${APPLICATIONS_VM1[@]} >> $PATH_LOG_VM1 

#dump database after convergence, done only once
FILE=$TMP_TRAINING_DIR"/dumpInjection"
if [ -f "$FILE" ]; then
    echo "$FILE exists, backup db injection not created" >> $PATH_LOG_VM1 
else 
    mysqldump -h 10.75.4.65 --port 3308 -u root -phelloworld db >> $FILE 
fi

#cleanup machine 2 - use a differnt script from original where it copies th updated traing 
sshpass -f <(printf '%s\n' $PASSWORD) ssh salnitri@10.75.4.66 "echo $PASSWORD | sudo -S nohup ${PATH_STOP_TEST_SCRIPT_VM2_PREINJECTION} ${PATH_LOG_EXTRA_VM2} ${#APPLICATIONS_VM2[@]} ${APPLICATIONS_VM2[@]} >> $PATH_LOG_VM2 2>&1" >> $PATH_LOG_EXTRA_VM1 2>&1 &

##########################

#take down spark containers
sudo docker-compose down >> $PATH_LOG_EXTRA_VM1 2>&1

echo "spark containers killed" >> $PATH_LOG_VM1

##clean
#clean file_table  table
#mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "TRUNCATE TABLE file_table" >> $PATH_LOG_EXTRA_VM1 2>&1

#clean events table ->  to keep tracks of new events
mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "TRUNCATE TABLE events" >> $PATH_LOG_EXTRA_VM1 2>&1

#clean detailed events table ->  to keep tracks of new events
mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "TRUNCATE TABLE events_details" >> $PATH_LOG_EXTRA_VM1 2>&1

#update global counter 
#mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "update global_counter set value=0" >> $PATH_LOG_EXTRA_VM1 2>&1

echo "DB cleaned" >> $PATH_LOG_VM1

echo $ACTIONSNUMBER