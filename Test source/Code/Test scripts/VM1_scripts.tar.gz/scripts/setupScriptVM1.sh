#!/bin/bash
##in VM1
#to be executed as root
#minio server, my sql and adminer should be up and running

#paramters
#1- size of the array of application to be deployed in VM1
#2- array of application to be deployed in VM1
#3- size of the array of application to be deployed in VM2
#4- array of application to be deployed in VM2


echo "setupStriptVM1 start"

#add variables
. configuration.sh

#add libraries of functions
. $PATH_LIBRARY

#Change current directiry
cd /home/mangiaracina/prova/VM1

#retrive array of application to build
#shift the alredy saved parameters, to correctly retrive array,
#shift 2 #commented since there are no other parameters

############extract arrays
######extract first array
declare -i num_args; #integers
declare -a TRAINING_VM1; #declare the name of the array

TRAINING_VM1=( )
num_args=$1; shift
#decrease num args and ceck idf the decresed value is higher than 0
while (( num_args-- > 0 )) ; do 
    TRAINING_VM1+=( "$1" ); shift
done

######extract second array
declare -a TRAINING_VM2; #declare the name of the array

TRAINING_VM2=( )
num_args=$1; shift
#decrease num args and ceck idf the decresed value is higher than 0
while (( num_args-- > 0 )) ; do 
    TRAINING_VM2+=( "$1" ); shift
done
###########################

echo "Parameters" 
echo "Training applications VM1: "${TRAINING_VM1[@]}
echo "Traing applications VM2: "${TRAINING_VM2[@]}

#set a unique array fo all applications
TRAINING_VMS=(${TRAINING_VM1[@]} ${TRAINING_VM2[@]})

#check that minio, mysql and adminer containers are up and running.

if [ ! "$(docker ps -q -f name=minio)" ] || [ ! "$(docker ps -q -f name=db_admin_1)" ] || [ ! "$(docker ps -q -f name=db_mysql-development_1)" ]; then
    echo "minio, mysql or adminer contrainer are not running, test stopped"
    kill $$
fi

echo "Check container passed"

#clear docker
docker system prune -f -a --volumes
echo "docker pruned"

#remove old output training
#remove all files since this is a fresh start
find . -regextype posix-extended -regex ".*(IC|IM|CR).*" -type f -exec rm {} \;
echo "old output training removed"

#setup permissions
chmod 777 -R ./


##update add_nodes.py --> only if i want to change the number of nodes, for the traing i always traing for 30 nodes

#update db.py for each spark folder --> questo solo se voglio cambiare il numero di nodi nel training
#find . -regextype posix-extended -regex ".*db.py" -type f -exec sed -i 's/N =.*/N = $MAX_APPLICATIONS_NUMBER/g' {} \; #NOT NEEDED FOR TRAINING

#clean availability table
mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "TRUNCATE TABLE availability"

#clean latency table
mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "TRUNCATE TABLE latency"

echo "Database cleaned"

#modify all actions.py files with the list of nodes and uncommenting the ones required
setNodesVector $MAX_APPLICATIONS_NUMBER $MAX_EMPTY_NODES_NUMBER $MAX_AVAILABLE_NODE "${TRAINING_VMS[@]}"
echo "action py cleared"

#launch training on VM2 
# sshpass -f <(printf '%s\n' $PASSWORD) ssh salnitri@10.75.4.66 "echo '$PASSWORD' | sudo -S nohup $PATH_START_SETUP_SCRIPT_VM2 $MAX_APPLICATIONS_NUMBER $MAX_EMPTY_NODES_NUMBER $MAX_AVAILABLE_NODE $PATH_DOCKER_COMPOSE_VM1 >> $PATH_LOG_TRAINING_VM2 2>&1" &
sshpass -f <(printf '%s\n' $PASSWORD) ssh salnitri@10.75.4.66 "echo '$PASSWORD' | sudo -S nohup $PATH_START_SETUP_SCRIPT_VM2 $MAX_APPLICATIONS_NUMBER $MAX_EMPTY_NODES_NUMBER $MAX_AVAILABLE_NODE $PATH_DOCKER_COMPOSE_VM2 ${#TRAINING_VM1[@]} ${TRAINING_VM1[@]} ${#TRAINING_VM2[@]} ${TRAINING_VM2[@]} >> $PATH_LOG_TRAINING_VM2 2>&1" &
echo "training VM2 launched"

#create docker compose based on the number of application
#creates half of the applications, the remaining application will be started in vm2, that is more free than vm1. integer division
createDockerComposeVector $PATH_DOCKER_COMPOSE_VM1 "${TRAINING_VM1[@]}" >> $PATH_LOG_TRAINING_VM1_EXTRA 2>&1

#compilo container 
docker-compose build >> $PATH_LOG_TRAINING_VM1_EXTRA 2>&1

#creo container spark ( tutti, anche se serve solo spark1)
docker-compose up -d >> $PATH_LOG_TRAINING_VM1_EXTRA 2>&1

while [ ! "$(docker ps -q -f name=spark1)" ]
do
    echo "checked, container not created, waiting 1 minutes"
    sleep 1m
done

echo "docker container (spark1) launched"

#genero configurazione casuale, in vm
docker exec spark1 python add_nodes.py >> $PATH_LOG_TRAINING_VM1_EXTRA 2>&1

echo "add node launched in spark 1"

NOW=$(date +"%d-%m-%Y-%T")
FILE_NAME_DUMP=$PATH_DUMP_DB"dump"$NOW"_"$MAX_APPLICATIONS_NUMBER"_"$MAX_EMPTY_NODES_NUMBER_"_"$MAX_AVAILABLE_NODE

echo $FILE_NAME_DUMP

#backup database
mysqldump -h 10.75.4.65 --port 3308 -u root -phelloworld db >> $FILE_NAME_DUMP

echo "dumped db"

#starts half of the applications (toxyproxy e avvia spark history server ), the remaining application will be strted in vm2, that is more free than vm1. integer division
initialiseSparkNodes_vector "${TRAINING_VM1[@]}" >> $PATH_LOG_TRAINING_VM1_EXTRA 2>&1
echo "spark history server and toxi proxy launched"

#start traing
startTraining_vector "${TRAINING_VM1[@]}" >> $PATH_LOG_TRAINING_VM1_EXTRA 2>&1
#this will wait all training to be finished
wait

echo "training ended"

#copy output training
#copy in all spark folers since for next builds (for test) these files are needed as well
copyOutputTraining_vector "${TRAINING_VM1[@]}"

echo "output training copied in spark folders"

#Kill all spark containers
docker-compose down
echo "spark cotainers stopped"

echo "setup finished"