#!/bin/bash
#configuration file
#use to store all significant variables 

#path to the library
PATH_LIBRARY="/home/salnitri/scripts/library_V2.sh"

#password admin n VM1 and VM2
PASSWORD="salnitri123"


### setup variables
##path log in VM2
PATH_LOG_TRAINING_VM2="/home/salnitri/scripts/trainingLogs"

##path log in VM1
PATH_LOG_TRAINING_VM1_EXTRA="/home/salnitri/scripts/trainingLogs_extra"

PATH_DUMP_DB="/home/salnitri/dumps/"

PATH_DOCKER_COMPOSE_VM1="/home/mangiaracina/prova/VM1/docker-compose.yml"
PATH_DOCKER_COMPOSE_VM2="/home/mangiaracina/prova2/VM2/docker-compose.yml"

PATH_START_SETUP_SCRIPT_VM2="/home/salnitri/scripts/setupScriptVM2.sh"

#set the maximum number of nodes to use in the tests
#max is MAX_AVAILABLE_NODE, i.e., 30 nodes, for more nodes need to manually add node creation in action.py adding lines such as:
#N4 = Node(4, 1, db.get_availability(4), db.get_latency(1, 4))
#ATTENTION: MAX_APPLICATIONS_NUMBER+ MAX_EMPTY_NODES_NUMBER=<MAX_AVAILABLE_NODE=
MAX_APPLICATIONS_NUMBER=20
MAX_EMPTY_NODES_NUMBER=10
MAX_AVAILABLE_NODE=30


### test variables

#in the machine where this cript is called (VM1)
PATH_LOG_VM1="/home/salnitri/scripts/logTest"
#in the machine where this cript is called (VM1), contains not so important info as docker output
PATH_LOG_EXTRA_VM1="/home/salnitri/scripts/logTest_extra"


#path for the longs in VM2
PATH_LOG_VM2="/home/salnitri/scripts/logTest"
#in the machine where this script is called (VM2), contains not so important info as docker output
PATH_LOG_EXTRA_VM2="/home/salnitri/scripts/logTest_extra"

#part for scripts in VM2
#setup test
PATH_SETUP_TEST_SCRIPT_VM2="/home/salnitri/scripts/testScriptVM2_setup.sh"
#start test
PATH_START_TEST_SCRIPT_VM2="/home/salnitri/scripts/testScriptVM2_start.sh"
#end test
PATH_STOP_TEST_SCRIPT_VM2="/home/salnitri/scripts/testScriptVM2_stop.sh"

#paths to docker compose
PATH_DOCKER_COMPOSE_VM1="/home/mangiaracina/prova/VM1/docker-compose.yml"
PATH_DOCKER_COMPOSE_VM2="/home/mangiaracina/prova2/VM2/docker-compose.yml"


#####injection variables
#path for temporary storage of training data and dump database
TMP_TRAINING_DIR="/home/salnitri/scripts/tmpInjection"

#path to VM2 script to setup script
PATH_SETUP_TEST_SCRIPT_VM2_VECTOR="/home/salnitri/scripts/testScriptVM2_setup_vector.sh"

#path to VM2 script to start preinjection script
PATH_START_TEST_SCRIPT_VM2_PREINJECTION="/home/salnitri/scripts/testScriptVM2_start_preInjection.sh"

#path to VM2 script to stop preinjection script
PATH_STOP_TEST_SCRIPT_VM2_PREINJECTION="/home/salnitri/scripts/testScriptVM2_stop_preInjection.sh"

#path to VM2 script to start injection script
PATH_STOP_TEST_SCRIPT_VM2_INJECTION="/home/salnitri/scripts/testScriptVM2_stop_injection.sh"