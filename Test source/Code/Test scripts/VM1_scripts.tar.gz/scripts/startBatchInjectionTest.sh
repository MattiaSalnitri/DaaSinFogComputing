#!/bin/bash

#start setup
echo "start batch"

echo "start training"
date

#use existing training
#./setupScriptVM1.sh >> trainingLogs 2>&1

date
echo "training finished"

echo "start pre test"
date

BATCH=3

#start tests
EMPTYNODES=0
APPLICATIONS_NUMBER=10
POSITION=1



#create arrays of applications
#APPLICATIONS_VM1 must always have 1 as first element
APPLICATIONS_VM1=( 1 2 3 4 5 )
APPLICATIONS_VM2=( 11 12 13 14 15 ) 

echo "start batch"
date
echo "Setup applications VM1: "${APPLICATIONS_VM1[@]}
echo "Setup applications VM2: "${APPLICATIONS_VM2[@]}

echo "start pre injection"

#setup
./testScriptSetupVM1_vector.sh $APPLICATIONS_NUMBER $EMPTYNODES "${#APPLICATIONS_VM1[@]}" "${APPLICATIONS_VM1[@]}"  "${#APPLICATIONS_VM2[@]}" "${APPLICATIONS_VM2[@]}" 

#call test START
TESTRESULT=$(./testScriptStartVM1_preInjection.sh $POSITION $APPLICATIONS_NUMBER $EMPTYNODES "${#APPLICATIONS_VM1[@]}" "${APPLICATIONS_VM1[@]}"  "${#APPLICATIONS_VM2[@]}" "${APPLICATIONS_VM2[@]}" )

#save adaptation actions to convergence
echo "Actions without injected nodes: "$TESTRESULT";">>"batchInject_"$BATCH

for NEWNODE in 6 7 8 9 10 16 17 18 19 20
# for NEWNODE in 7 8 9
do
    echo "start injection"

    #create arrays of applications
    #PPLICATIONS_VM1 must always have 1 as first element
    APPLICATIONS_VM1=( 1 2 3 4 5 )
    APPLICATIONS_VM2=( 11 12 13 14 15 )

    #add applications on VM
    if (( $NEWNODE <= 10 ));
    then
        APPLICATIONS_VM1+=( $NEWNODE )
    else
        APPLICATIONS_VM2+=( $NEWNODE )
    fi


    echo "start batch"
    date
    echo "Test applications VM1: "${APPLICATIONS_VM1[@]}
    echo "Test applications VM2: "${APPLICATIONS_VM2[@]}

    #configure with new node, change actyon.py and db.py
    #add +1 because we inject a new application
    ./testScriptSetupVM1_vector.sh $(( APPLICATIONS_NUMBER+1 )) $EMPTYNODES "${#APPLICATIONS_VM1[@]}" "${APPLICATIONS_VM1[@]}"  "${#APPLICATIONS_VM2[@]}" "${APPLICATIONS_VM2[@]}" 

    #start test again with new node
    TESTRESULT=$(./testScriptStartVM1_injection.sh $POSITION $(( APPLICATIONS_NUMBER+1 )) $EMPTYNODES "${#APPLICATIONS_VM1[@]}" "${APPLICATIONS_VM1[@]}"  "${#APPLICATIONS_VM2[@]}" "${APPLICATIONS_VM2[@]}")

    #Save results convergence after new nodes
    echo $TESTRESULT>>"batchInject"

done

##clean training data
./cleanTrainingData.sh "${#APPLICATIONS_VM1[@]}" "${APPLICATIONS_VM1[@]}"  "${#APPLICATIONS_VM2[@]}" "${APPLICATIONS_VM2[@]}" 

echo "end injection test"