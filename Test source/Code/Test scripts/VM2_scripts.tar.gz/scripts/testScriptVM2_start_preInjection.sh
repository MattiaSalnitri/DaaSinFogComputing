#!/bin/bash
#script test in VM2

#paramters
#1- number of applications
#2- path to store extra logs
#5- size of the array of application to be deployed in VM2
#6- array of application to be deployed in VM2

PATH_LIBRARY="/home/salnitri/scripts/library_V2.sh"


echo "Start script VM2 launched pre _injection" 
echo "parameters: "$1","$2","

#aggiungo linea con data inizio iterazione
date

#add libraries of functions
. $PATH_LIBRARY

#set the number of nodes from parameters
APPLICATIONS_NUMBER=$1

#in the machine where this script is called (VM2), contains not so important info as docker output
PATH_LOG_EXTRA_VM2=$2

#retrive array of application to build
#shift the already saved parameters, to correctly retrive array
shift 2

############extract array
declare -i num_args; #integers
declare -a APPLICATIONS_VM2; #declare the name of the array

APPLICATIONS_VM2=( )
num_args=$1; shift
while (( num_args-- > 0 )) ; do #decrease num args and ceck idf the decresed value is higher than 0
    APPLICATIONS_VM2+=( "$1" ); shift
done
###########################

echo "Applications VM2: "${APPLICATIONS_VM2[@]}

#change currect dir
cd /home/mangiaracina/prova2/VM2

##########################
#different part: control if tmp exists
TMP_TRAINING_DIR="/home/salnitri/scripts/tmpInjection"
if [ ! -d "$TMP_TRAINING_DIR" ]; then
  ### if $DIR does not exist, create and copy  original vectors ###
  echo "Original traing files copied in ${TMP_TRAINING_DIR}..."
  mkdir $TMP_TRAINING_DIR
  for ((i=1;i<=10;i++));#copy all traing, for backup to be restored later
    do  
		#create the sub folder
		mkdir $TMP_TRAINING_DIR/spark$(( i+10 ))
		#copy all training files
        cp /home/mangiaracina/prova2/VM2/spark$(( i+10 ))/I*  $TMP_TRAINING_DIR/spark$(( i+10 ))/.
    done

fi
##########################

#Check if minio container is up and running
#if not the scripts stops
checkContainersVM2 >> $PATH_LOG_EXTRA_VM2 2>&1
echo "Check container passed"

docker-compose up -d >> $PATH_LOG_EXTRA_VM2 2>&1

# start spark history server and toxiproxy
#./start.sh &
#starts half of the applications, plus the application from te module, vm2 is more free than vm2
##initialiseSparkNodesVM2 $(( (APPLICATIONS_NUMBER/2)+(APPLICATIONS_NUMBER%2) )) >> $PATH_LOG_EXTRA_VM2 2>&1
initialiseSparkNodes_vector ${APPLICATIONS_VM2[@]} >> $PATH_LOG_EXTRA_VM2 2>&1
echo "spark history server and toxiproxy launched"

#this can be removed now
echo "giving time to boot servers"
sleep 5m 


#starts half of the applications, plus the application from te module, vm2 is more free than vm2
#startTestVM2 $(( (APPLICATIONS_NUMBER/2)+(APPLICATIONS_NUMBER%2) )) >> $PATH_LOG_EXTRA_VM2 2>&1
startTest_vector ${APPLICATIONS_VM2[@]} >> $PATH_LOG_EXTRA_VM2 2>&1
echo "test launched"


#aggiungo linea con data fine iterazione
date