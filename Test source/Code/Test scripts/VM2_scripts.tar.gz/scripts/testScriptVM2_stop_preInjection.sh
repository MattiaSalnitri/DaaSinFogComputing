#!/bin/bash
#script test in VM2

#paramters
#1- path to store extra logs
#3- size of the array of application to be deployed in VM2
#4- array of application to be deployed in VM2

echo "Stop script VM2 launched preinjection"

#print parameters 
echo "Parameters:"
for i in $*; do 
	echo $i 
done

PATH_LIBRARY="/home/salnitri/scripts/library_V2.sh"
#add libraries of functions
. $PATH_LIBRARY

PATH_LOG_EXTRA_VM2=$1

#retrive array of application to build
#shift the already saved parameters, to correctly retrive array
shift 1

############extract array
declare -i num_args; #integers
declare -a APPLICATIONS_VM2; #declare the name of the array

APPLICATIONS_VM2=( )
num_args=$1; shift
echo "size array input: "$num_args
#decrease num args and ceck if the decresed value is higher than 0
while (( num_args-- > 0 )) ; do 
    APPLICATIONS_VM2+=( "$1" ); shift
done
###########################

echo "Applications VM2: "${APPLICATIONS_VM2[@]}

#change currect dir
cd /home/mangiaracina/prova2/VM2

##########################
#remove training and copy the updated one from spark machines

#remove training for the element specifird in array
for i in ${APPLICATIONS_VM2[@]} 
do  
	#remove all vectors
	find spark$i -regextype posix-extended -regex ".*(IC|IM|CR).*" -type f -exec rm {} \;
done

#copy the updated training in the folders for the build
#copy in all spark folers since for next builds (for test) these files are needed as well
#backupTrainingVectorsVM2 $(( (APPLICATIONS_NUMBER/2)+(APPLICATIONS_NUMBER%2) ))
backupTrainingVectors_vector "/home/mangiaracina/prova2/VM2/" ${APPLICATIONS_VM2[@]}


##########################


#scrivo data fine test
date

#butto giu' i container spark
docker-compose down & >> $PATH_LOG_EXTRA_VM2 2>&1
echo "spark containers killed"