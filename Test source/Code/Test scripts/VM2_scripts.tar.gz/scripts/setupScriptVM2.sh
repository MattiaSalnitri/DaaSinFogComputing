#!/bin/bash
#in VM2
#to be executed as root
#minio server should be up and running and populated

#paramters
#1- number of max applications
#2- number of empty nodes
#3- number of max available node
#4- path to docker compose for spark containers
#5- size of the array of application to be deployed in VM1
#6- array of application to be deployed in VM1
#7- size of the array of application to be deployed in VM2
#8- array of application to be deployed in VM2

echo "setupStriptVM2 start"

PATH_LIBRARY="/home/salnitri/scripts/library_V2.sh"

#add libraries of functions
. $PATH_LIBRARY

#Change current directiry
cd /home/mangiaracina/prova2/VM2

#set the maximum number of nodes to use in the tests
#max is MAX_AVAILABLE_NODE, i.e., 30 nodes, for more nodes need to manually add node creation in action.py adding lines such as:
#N4 = Node(4, 1, db.get_availability(4), db.get_latency(1, 4))
#ATTENTION: MAX_APPLICATIONS_NUMBER+ MAX_EMPTY_NODES_NUMBER=<MAX_AVAILABLE_NODE=
MAX_APPLICATIONS_NUMBER=$1
MAX_EMPTY_NODES_NUMBER=$2
MAX_AVAILABLE_NODE=$3
PATH_DOCKER_COMPOSE_VM2=$4

#retrive array of application to build
#shift the alredy saved parameters, to correctly retrive array,
shift 4 #commented since there are no other parameters

############extract arrays
######extract first array
declare -i num_args; #integers
declare -a TRAINING_VM1; #declare the name of the array

TRAINING_VM1=( )
num_args=$1; shift
#decrease num args and ceck idf the decresed value is higher than 0
while (( num_args-- > 0 )) ; do 
    TRAINING_VM1+=( "$1" ); shift
done

######extract second array
declare -a TRAINING_VM2; #declare the name of the array

TRAINING_VM2=( )
num_args=$1; shift
#decrease num args and ceck idf the decresed value is higher than 0
while (( num_args-- > 0 )) ; do 
    TRAINING_VM2+=( "$1" ); shift
done
###########################


#set a unique array fo all applications
TRAINING_VMS=(${TRAINING_VM1[@]} ${TRAINING_VM2[@]})

echo "Parameters" 
echo "Max application number: "$MAX_APPLICATIONS_NUMBER
echo "Max empty nodes number: "$MAX_EMPTY_NODES_NUMBER
echo "Max available node: "$MAX_AVAILABLE_NODE
echo "path to docker compose: "$PATH_DOCKER_COMPOSE_VM2
echo "Training applications VM1: "${TRAINING_VM1[@]}
echo "Traing applications VM2: "${TRAINING_VM2[@]}

#number of all nodes
NODE_NUMBER=$((MAX_APPLICATIONS_NUMBER + MAX_EMPTY_NODES_NUMBER))

#Check minio container is up and running

if [ ! "$(docker ps -q -f name=minio)" ]; then
    echo "minio contrainer is not running, test stopped"
    kill $$
fi

echo "Check container passed"

#clear docker
docker system prune -f -a --volumes
echo "docker pruned"

#remove old output training, these file are the one copied in the last part
find . -regextype posix-extended -regex ".*(IC|IM|CR).*" -type f -exec rm {} \;
echo "old output training removed"

#setup permissions
chmod 777 -R ./


#modify all actions.py files with the list of nodes and uncommenting the ones required
setNodesVector $MAX_APPLICATIONS_NUMBER $MAX_EMPTY_NODES_NUMBER $MAX_AVAILABLE_NODE "${TRAINING_VMS[@]}"
echo "action py cleared" 


#create docker compose based on the number of application
#creates half of the applications, plus the application from te module, vm2 is more free than vm1.integer division
createDockerComposeVector $PATH_DOCKER_COMPOSE_VM2 "${TRAINING_VM2[@]}"

#compilo container 
docker-compose build

#creo container spark ( tutti, anche se serve solo spark1)
docker-compose up -d

#check spark1 is un and running
while [ ! "$(docker ps -q -f name=spark11)" ]
do
    echo "checked, container not created, waiting 1 minutes"
    sleep 1m
done

#calculate permutation of NODE_NUMBER taken by 2, i.e., (NODE_NUMBER!/(NODE_NUMBER-2) )+NODE_NUMBER
#added NODE_NUMBER at the end, because we consider connecton of node with himself
ENTRIES_NEEDED=$(echo "define f(x) {if (x>1){return x*f(x-1)};return 1} (f($NODE_NUMBER)/f($NODE_NUMBER-2))+$NODE_NUMBER" | bc)

echo $ENTRIES_NEEDED

COUNT_LATENCY_ENTRIES=0

while [ $COUNT_LATENCY_ENTRIES -ne $ENTRIES_NEEDED ] 
do
	#controllo tabella latency
	COUNT_LATENCY_ENTRIES=$(mysql -h 10.75.4.65 --port 3308 -u root -phelloworld -D db -N -e "SELECT count(*) from latency")

	echo "databse not ready, waiting.."
	sleep 3m
done


#starts containers in VM
#in C2:  initialized toxi proxy and starts spark history server
#starts half of the applications, plus the application from te module, vm2 is more free than vm1
initialiseSparkNodes_vector "${TRAINING_VM2[@]}"
echo "spark history server and toxi proxy launched"

echo "training started"

#starts training
startTraining_vector "${TRAINING_VM2[@]}"
#this will wait all training to be finished
wait

echo "training ended"


#copio output training
#devo copiare in cartella di ogni spark perche poi quando vado a fare build e run, deve tirarsi su anche quei file di training
copyOutputTraining_vector "${TRAINING_VM2[@]}"

echo "output training copied in spark folders"

#killo tutti container spark
docker-compose down
echo "spark cotainers stopped" 

echo "setup finished"