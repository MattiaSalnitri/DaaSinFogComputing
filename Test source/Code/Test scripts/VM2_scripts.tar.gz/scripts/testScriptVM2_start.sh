#!/bin/bash
#script test in VM2

#paramters
#1- number of applications
#2- path to store extra logs
#5- size of the array of application to be deployed in VM2
#6- array of application to be deployed in VM2

echo "Start script VM2 launched"
#add start time 
date

PATH_LIBRARY="/home/salnitri/scripts/library_V2.sh"

#add libraries of functions
. $PATH_LIBRARY

#change currect dir
cd /home/mangiaracina/prova2/VM2

#set the number of nodes from parameters
APPLICATIONS_NUMBER=$1
#in the machine where this script is called (VM2), contains not so important info as docker output
PATH_LOG_EXTRA_VM2=$2

#retrive array of application to build
#shift the already saved parameters, to correctly retrive array
shift 2

############extract arrays
######extract first array
declare -i num_args; #integers
declare -a APPLICATIONS_VM1; #declare the name of the array

APPLICATIONS_VM1=( )
num_args=$1; shift
while (( num_args-- > 0 )) ; do #decrease num args and ceck idf the decresed value is higher than 0
    APPLICATIONS_VM1+=( "$1" ); shift
done

######extract second array
declare -a APPLICATIONS_VM2; #declare the name of the array

APPLICATIONS_VM2=( )
num_args=$1; shift
while (( num_args-- > 0 )) ; do #decrease num args and ceck idf the decresed value is higher than 0
    APPLICATIONS_VM2+=( "$1" ); shift
done
###########################

echo "Parameters"
echo "Application number: "$APPLICATIONS_NUMBER
echo "Path to extra logs: "$PATH_LOG_EXTRA_VM2
echo "Applications VM2: "${APPLICATIONS_VM2[@]} 


#Check if minio container is up and running
#if not the scripts stops
checkContainersVM2 >> $PATH_LOG_EXTRA_VM2 2>&1
echo "Check container passed"

docker-compose up -d >> $PATH_LOG_EXTRA_VM2 2>&1

# start spark history server and toxiproxy
#./start.sh &
#starts half of the applications, plus the application from te module, vm2 is more free than vm2
initialiseSparkNodes_vector ${APPLICATIONS_VM2[@]} >> $PATH_LOG_EXTRA_VM2 2>&1
echo "spark history server and toxiproxy launched"

#this can be removed now
echo "giving time to boot servers"
sleep 5m 

#starts half of the applications, plus the application from te module, vm2 is more free than vm2
startTest_vector ${APPLICATIONS_VM2[@]} >> $PATH_LOG_EXTRA_VM2 2>&1
echo "test launched"

#aggiungo linea con data fine iterazione
date