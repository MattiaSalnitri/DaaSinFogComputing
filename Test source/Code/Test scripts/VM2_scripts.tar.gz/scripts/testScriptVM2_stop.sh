#!/bin/bash
#script test in VM2
echo "Stop script VM2 launched"

PATH_LOG_EXTRA_VM2=$1

#change currect dir
cd /home/mangiaracina/prova2/VM2

#scrivo data fine test
date

#butto giu' i container spark
docker-compose down & >> $PATH_LOG_EXTRA_VM2 2>&1
echo "spark containers killed"