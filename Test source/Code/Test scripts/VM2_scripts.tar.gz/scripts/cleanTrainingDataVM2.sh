#!/bin/bash

#script cleaning data in VM2

echo "start cleaning training data"

#paramters
#1- size of array that contains the set of application to be built in VM2
#2- set of application to be built in VM2

############extract array
declare -i num_args; #integers
declare -a APPLICATIONS_VM2; #declare the name of the array
 

APPLICATIONS_VM2=( )
num_args=$1; shift
echo "size array input: "$num_args
#decrease num args and ceck idf the decresed value is higher than 0
while (( num_args-- > 0 )) ; do 
    APPLICATIONS_VM2+=( "$1" ); shift
done
###########################

echo "Applications VM2: "${APPLICATIONS_VM2[@]}

#change currect dir
cd /home/mangiaracina/prova2/VM2


#restore vector backup
#remove all training 
#remove training for the element specific in array
for i in ${APPLICATIONS_VM2[@]}
do  
	#remove all vectors
	find spark$i -regextype posix-extended -regex ".*(IC|IM|CR).*" -type f -exec rm {} \;
done

echo "updated training removed"

# copy all backup in original folder
#use 10 as costant for spark machines since I want to backup all machines
TMP_TRAINING_DIR="/home/salnitri/scripts/tmpInjection"
#remove training for the element specified in array
for i in ${APPLICATIONS_VM2[@]}
do  
	#copy all training files
	cp  $TMP_TRAINING_DIR/spark$i/* /home/mangiaracina/prova2/VM2/spark$i/.
done


echo "old training restored"