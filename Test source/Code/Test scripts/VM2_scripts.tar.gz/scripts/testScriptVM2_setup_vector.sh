#!/bin/bash
#script test in VM2

#paramters
#1- number of applications
#2- number of empty nodes
#3- number of max available nodes
#4- path to log extra info
#5- path top docker compose file for applications
#6- size of the array of application to be deployed in VM1
#7- array of application to be deployed in VM1
#8- size of the array of application to be deployed in VM2
#9- array of application to be deployed in VM2

PATH_LIBRARY="/home/salnitri/scripts/library_V2.sh"

#add libraries of functions
. $PATH_LIBRARY

echo "Start tsetSecriptVM2_setup launched"

#change currect dir
cd /home/mangiaracina/prova2/VM2

#aggiungo linea con data inizio iterazione
date

#set the number of nodes from parameters
APPLICATIONS_NUMBER=$1
EMPTY_NODES_NUMBER=$2
MAX_AVAILABLE_NODE=$3
#in the machine where this script is called (VM2), contains not so important info as docker output
PATH_LOG_EXTRA_VM2=$4
#path to docker compose
PATH_DOCKER_COMPOSE_VM2=$5

#retrive array of application to build
#shift the already saved parameters, to correctly retrive array
shift 5

############extract arrays
######extract first array
declare -i num_args; #integers
declare -a APPLICATIONS_VM1; #declare the name of the array

APPLICATIONS_VM1=( )
num_args=$1; shift
#decrease num args and ceck idf the decresed value is higher than 0
while (( num_args-- > 0 )) ; do 
    APPLICATIONS_VM1+=( "$1" ); shift
done

######extract second array
declare -a APPLICATIONS_VM2; #declare the name of the array

APPLICATIONS_VM2=( )
num_args=$1; shift
#decrease num args and ceck idf the decresed value is higher than 0
while (( num_args-- > 0 )) ; do 
    APPLICATIONS_VM2+=( "$1" ); shift
done
###########################

#set a unique array fo all applications
APPLICATIONS=(${APPLICATIONS_VM1[@]} ${APPLICATIONS_VM2[@]})

echo "Parameters"
echo "Number of applications: "$APPLICATIONS_NUMBER
echo "Number of empty nodes: "$EMPTY_NODES_NUMBER
echo "numbner of maximum available nodes: "$MAX_AVAILABLE_NODE
echo "Path to extra logs: "$PATH_LOG_EXTRA_VM2
echo "Path to docker compose: "$PATH_DOCKER_COMPOSE_VM2
echo "Applications VM1: "${APPLICATIONS_VM1[@]} 
echo "Applications VM2: "${APPLICATIONS_VM2[@]} 

#Check if minio container is up and running
#if not the scripts stops
checkContainersVM2 >> $PATH_LOG_EXTRA_VM2 2>&1
echo "Check container passed"

#clear docker
docker system prune -f -a --volumes
echo "docker pruned"

#update db.py for each spark folder , to set the number of applications
find . -regextype posix-extended -regex ".*db.py" -type f -exec sed -i "s/N =.*/N = ${APPLICATIONS_NUMBER}/g" {} \; >> $PATH_LOG_EXTRA_VM2 2>&1

echo "db.py updated"

#modify all actions.py files with the list of nodes and uncommenting the ones required
setNodesVector $APPLICATIONS_NUMBER $EMPTY_NODES_NUMBER $MAX_AVAILABLE_NODE "${APPLICATIONS[@]}" >> $PATH_LOG_EXTRA_VM2 2>&1

echo "action.py updated"

#create docker compose based on the number of application
#creates half of the applications, the remaining application will be started in vm2, that is more free than vm2. integer division
createDockerComposeVector $PATH_DOCKER_COMPOSE_VM2 "${APPLICATIONS_VM2[@]}" >> $PATH_LOG_EXTRA_VM2 2>&1

docker-compose build >> $PATH_LOG_EXTRA_VM2 2>&1
#here I implicilty wait to end the command, DON'T put "&"

echo "Images for docker container compiled"