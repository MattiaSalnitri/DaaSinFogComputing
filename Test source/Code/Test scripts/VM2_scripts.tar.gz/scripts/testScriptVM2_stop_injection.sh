#!/bin/bash
#script test in VM2
echo "Stop script VM2 launched injection"

#print parameters 
# echo "Parameters:"
# for i in $*; do 
# 	echo $i 
# done

PATH_LOG_EXTRA_VM2=$1

#change currect dir
cd /home/mangiaracina/prova2/VM2

#Write date end test
date


#stop spark containers
docker-compose down & >> $PATH_LOG_EXTRA_VM2 2>&1
echo "spark containers killed"