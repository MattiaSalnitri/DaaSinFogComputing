#!/bin/bash
#library functions

#comments all node descriptors
function resetNodes
{
        local MAX_AVAILABLE_NODE_THIS=$1
        
        for FILENAME in $(find . -regextype posix-extended -regex ".*actions.py" -type f) 
        do
            for ((i=1;i<=MAX_AVAILABLE_NODE_THIS;i++));
            do
                #echo "N$i = Node("
                sed -i "s/^N$i = Node(/#N$i = Node(/g" $FILENAME
            done
        done
}


#controllo che i container minio, mysql and aminer siano su.
#in caso contrario esco
function checkContainersVM1
{
        if [ ! "$(docker ps -q -f name=minio)" ] || [ ! "$(docker ps -q -f name=db_admin_1)" ] || [ ! "$(docker ps -q -f name=db_mysql-development_1)" ]; then
            echo "minio, mysql or adminer contrainer are not running, test stopped"
            kill $$
        fi
}

#controllo che il container con minio sian su.
#in caso contrario esco
function checkContainersVM2
{
        if [ ! "$(docker ps -q -f name=minio)" ]; then
            echo "minio contrainer is not running, test stopped"
            kill $$
        fi
}

#copy output training VM1
#parameters
#1 last spark machine, included
#similar to copyOutputTrainingVM1, but it changes the target folder, this extract used vector
function backupTrainingVectorsVM1
{
    for ((i=1;i<=$1;i++));
    do  
        #echo "creating tmp folder in spark"$i
        docker exec spark$i bash -c "mkdir -p /extract; mv /usr/spark-2.4.1/bin/I* /extract"
        #echo "copying in spark"$i
        docker cp spark$i:/extract/. /home/mangiaracina/prova/VM1/spark$i/.

        #docker cp spark$i:/usr/spark-2.4.1/bin/output_training/. ./spark$i/
    done
}

#copy output training VM2
#parameters
#1 last spark machine, included
#similar to copyOutputTrainingVM1, but it changes the target folder, this extract used vector
function copyOutputTrainingVM2
{
    for ((i=1;i<=$1;i++));
    do  
        echo "creating tmp folder in spark"$(( $i+10 ))
        docker exec spark$(( $i+10 )) bash -c "mkdir -p /extract; mv /usr/spark-2.4.1/bin/I* /extract"
        echo "copying in spark"$(( $i+10 ))
        docker cp spark$(( $i+10 )):/extract/. /home/mangiaracina/prova2/VM2/spark$(( $i+10 ))/.
        #docker cp spark$(( $i+10 )):/usr/spark-2.4.1/bin/output_training/. ./spark$(( $i+10 ))/
    done
}


###vectors

#create the node list to add
#tekes in input the specific set of applications
function createNodeListVector 
{
        local APPLICATIONS_NUMBER_THIS=$1
        local EMPTY_NODES_NUMBER_THIS=$2
        #ignore previous paramters to correctly create array
        shift 2
        local APPLICATIONS_THIS=("$@")

        NODELIST="["
        #create node list from applications specified
        #start from 0!
        for ((i=0;i<APPLICATIONS_NUMBER_THIS;i++)); do
                if [ "${i}" -ne "0" ]; then
                        #skip the first comma, that is placed in front of the list item
                        NODELIST+=", "
                fi
                NODELIST+="N"${APPLICATIONS_THIS[i]}  
        done

        #add empty nodes startimh from 21 (20 is the limit of applications)
        for ((i=0;i<EMPTY_NODES_NUMBER_THIS;i++)); do
                NODELIST+=", "
                NODELIST+="N"$(( 21+$i ))
        done

        NODELIST+="]"
}


#modify all actions.py files adding the list of nodes and uncommenting the ones required
#takes node list fdrom function createNodeList, tha neds to be execute before
#takes in input the specific set of application to set
function setNodesVector
{
        local APPLICATIONS_NUMBER_THIS=$1
        local EMPTY_NODES_NUMBER_THIS=$2
        local MAX_AVAILABLE_NODE_THIS=$3
        #ignore previous paramters to correctly create array
        shift 3
        local APPLICATIONS_THIS=("$@")
        
        
        createNodeListVector $APPLICATIONS_NUMBER_THIS $EMPTY_NODES_NUMBER_THIS "${APPLICATIONS_THIS[@]}"
        
        #comments all node descriptors
        resetNodes $MAX_AVAILABLE_NODE
        
        for FILENAME in $(find . -regextype posix-extended -regex ".*actions.py" -type f) 
        do
            sed -i "s/\[N1, .*/$NODELIST/g" $FILENAME
            
            #uncomment aplications
            for ((i=0;i<APPLICATIONS_NUMBER_THIS;i++));
            do
                sed -i "s/^#N${APPLICATIONS_THIS[i]} = Node(/N${APPLICATIONS_THIS[i]} = Node(/g" $FILENAME
            done

            #uncomment empty nodes
            for ((i=0;i<EMPTY_NODES_NUMBER_THIS;i++));
            do
                sed -i "s/^#N$(( 21+$i )) = Node(/N$(( 21+$i )) = Node(/g" $FILENAME
            done

        done
}

#creates the docker-compose file
#parameters
#1 path to docker compose
#2 array of applications
function createDockerComposeVector
{

    local PATH_DOCKERFILE=$1
    #Array of applications
    #ignore previous paramters to correctly create array
    shift 1
    local APPLICATIONS_THIS=("$@")


#do not indent text, otherwise yml file will be broken
    local DOCKERCOMPOSE_FILE="version: '2.2'
services:
  toxiproxy:
           image : 'shopify/toxiproxy'
           container_name : toxiproxy
           network_mode: host
"

    for i in ${APPLICATIONS_THIS[@]}
        do  
#do not indent text, otherwise yml file will be broken        
            local TEXT="  spark$i:
        build : ./spark$i/
        network_mode: host
        stdin_open : true
        tty : true
        container_name : spark$i
"
            DOCKERCOMPOSE_FILE=$DOCKERCOMPOSE_FILE$TEXT
        done

        echo "$DOCKERCOMPOSE_FILE" > $PATH_DOCKERFILE
}

#copy output training 
#parameters
#1- path to copy backups
#2- array of vectors
#similar to copyOutputTrainingVM1/2, but it changes the target folder, this extract used vector
function backupTrainingVectors_vector
{
    local PATH_TO_COPY=$1
    shift

    #restore array second parameter
    local APPLICATIONS_TO_BACKUP=("$@")

    for i in ${APPLICATIONS_TO_BACKUP[@]}
    do  
        #docker exec spark$i bash -c "mkdir -p /extract; mv /usr/spark-2.4.1/bin/I* /extract"
        echo "creating tmp folder in spark"$i
        docker exec spark$i bash -c "mkdir -p /extract"

        echo "copying data of application spark"$i
        docker exec spark$i bash -c "mv /usr/spark-2.4.1/bin/I* /extract"

        echo "copying in spark"$i
        docker cp spark$i:/extract/. "${PATH_TO_COPY}"spark$i/.
    done
}

#Start tests 
#applications specified in array
function startTest_vector 
{
    local APPLICATIONS_TO_START=("$@")
    for i in ${APPLICATIONS_TO_START[@]}
    #for ((i=1;i<=$1;i++));
    do  
        docker exec spark$i python init.py &
    done
}

#Initialise spark hystory server and toxy proxy in VM1
#applications specified in array
function initialiseSparkNodes_vector
{
    local APPLICATIONS_TO_INITIALIZE=("$@")
    for i in ${APPLICATIONS_TO_INITIALIZE[@]}
    do  
        docker exec spark$i python init.py
    done
}

#Start training  VM1
#parameters
#applications specified in array
function startTraining_vector
{
    local APPLICATIONS_TO_TRAIN=("$@")
    for i in ${APPLICATIONS_TO_TRAIN[@]}
    do  
        nohup docker exec spark$i python training.py &
    done
}

#copy output training VM1
#parameters
#1 last spark machine, included
function copyOutputTraining_vector
{
    local APPLICATIONS_TO_COPY=("$@")
    for i in ${APPLICATIONS_TO_COPY[@]}
    do  
        docker cp spark$i:/usr/spark-2.4.1/bin/output_training/. ./spark$i/
    done
}

#creates the application vector used by batch script
function createApplicationsVectorTest
{
    # global variable
    APPLICATIONS_VM1=( )
    APPLICATIONS_VM2=( )

    # local variable
    local APPLICATIONS_NUMBER_THIS=$1
    local APPLICATION_NUMBER_VM1=$(( APPLICATIONS_NUMBER_THIS/2 ))
    local APPLICATION_NUMBER_VM2=$(( (APPLICATIONS_NUMBER_THIS/2)+(APPLICATIONS_NUMBER_THIS%2) ))
    

    for (( i=1; i<=$APPLICATION_NUMBER_VM1; i++ ))
    do  
        echo $i
        APPLICATIONS_VM1+=( $i )
    done

    for (( i=1; i<=$APPLICATION_NUMBER_VM2; i++ ))
    do  
        echo $i
        APPLICATIONS_VM2+=( $(( $i+10 )) )
    done
}