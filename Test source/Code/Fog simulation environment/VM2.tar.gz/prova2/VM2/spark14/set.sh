#!/bin/bash
curl -X POST http://127.0.0.1:8474/proxies/minioProxy14/toxics -d "@template.json"